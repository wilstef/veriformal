#ifndef TRANSLEXP_H_INCLUDED
#define TRANSLEXP_H_INCLUDED

using namespace std;  		//needed for string types

string translotherexp(string str);
string translexp (string str); 

//general functions
string lowercase(int i, string str);
string removechar(char ch, string str);

#endif //TRANSLEXP_H_INCLUDED