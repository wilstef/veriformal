#ifndef TRANSLSTM_H_INCLUDED
#define TRANSLSTM_H_INCLUDED

using namespace std;  		//needed for string types

string translstm (string str);
string translsl (string rhs);

#endif //TRANSLSTM_H_INCLUDED