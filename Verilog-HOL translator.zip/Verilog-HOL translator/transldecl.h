#ifndef TRANSLDECL_H_INCLUDED
#define TRANSLDECL_H_INCLUDED

using namespace std;  		//needed for string types

string transldecl(string str);

#endif //TRANSLDECL_H_INCLUDED