#ifndef TRANSLMODULE_H_INCLUDED
#define TRANSLMODULE_H_INCLUDED

using namespace std;  		//needed for string types

string translmodule (string str);

#endif //TRANSLMODULE_H_INCLUDED