#ifndef FLATTENING_H_INCLUDED
#define FLATTENING_H_INCLUDED

using namespace std;  		//needed for string types

string formatinput (string input);
string flattening (string str);
string getports (string str);
string gettoplist (string str);

#endif //FLATTENING_H_INCLUDED