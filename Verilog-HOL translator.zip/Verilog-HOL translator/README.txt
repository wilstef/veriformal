
This folder contains all C++ libraries written to 
translate input Verilog .v file into an 
equivalent Isabelle/HOL theory file and identifier names. 

Input file: 
  Verilog amodule.v file
  To translate an input file 'amodule.v', replace the value of
  string variable 'inputfile' in the main.ccp file, with 
  "amodule.v" and run the main.exe.  

Output files: 
  - output.thy Isabelle/HOL theory
  - names.txt identifier names speparated by |

 Input Verilog file and all instantiated Verilog module
 files should be in the main folder where
 the above libraries reside. After running the main.exe,
 it should create Isabelle/HOL theory as output.thy and 
 names.txt. 

 The following features of Verilog are currently not
 supported: 

  - operator precedence is not considered in epxressions. 
    better use parenthsis. 
  - part select in expressions only supports nat value, not variable
  - in declaration and left-hand side and delay of continuous assigns, parethesis 
    are not supported.
  - only single pair of outside parenthsis around a statement is supported. 
    ((x + y)), for example, is useless and is not supported. 
  - binary numbers are not supported (integer equivalent should be used instead)
  - nested blockes (e.g., nested if-then-else, while loop, ...) are not supported. 
  - forever, for, repeat, ... are not supported  
  - more than one parenthsis in sensitivity list
  - automating renaming of variables in the submodule (module instantiation)
  - nested instantiation (an instantiated module instantiate another)
  - un-ordered ports in module instantiation (e.g., first input argument to be
    assigned to the last argument in instantiated module)
      