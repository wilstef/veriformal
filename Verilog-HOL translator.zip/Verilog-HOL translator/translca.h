#ifndef TRANSLCA_H_INCLUDED
#define TRANSLCA_H_INCLUDED

using namespace std;  		//needed for string types

string translca (string str);

#endif //TRANSLCA_H_INCLUDED